import { P, a } from "./mermaid-parser.core.t07oox7U.js";
export {
  P as PacketModule,
  a as createPacketServices
};
