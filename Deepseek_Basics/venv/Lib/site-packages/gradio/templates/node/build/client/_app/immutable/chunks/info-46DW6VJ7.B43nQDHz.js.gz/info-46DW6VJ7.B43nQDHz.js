import { I, c } from "./mermaid-parser.core.t07oox7U.js";
export {
  I as InfoModule,
  c as createInfoServices
};
